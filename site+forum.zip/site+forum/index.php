<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Добро пожаловать </h1>
    </header>
    <nav>
        <a href="register.php">Регистрация</a>
        <a href="login.php">Авторизация</a>
        


<a href="posts.php">Посты</a>
    </nav>
    <?php if (isset($_SESSION['username'])): ?>
        <p>Вы авторизовались как <?php echo $_SESSION['username']; ?>. <a href="logout.php">выйти</a></p>
        <?php if ($_SESSION['role'] == 'admin'): ?>
            <a href="admin/index.php">Админ панель</a>
        <?php endif; ?>
    <?php endif; ?>
    <footer>
        удачного взлома 
    </footer>
</body>
</html>